create commands:
#mkdir parts
#compass create assets -r bootstrap-sass --using bootstrap
#echo on>>index.php
#echo on>>style.php

/*------------------------------------------------------*/
APP MAP:
-assets
--img
--sass
--stylesheets
--javascript
--fonts
--config.rb
-parts
index.php
style.css