<?php
class ThumbImages extends xPDOSimpleObject {}