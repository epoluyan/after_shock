<?php
/**
 * pdoPage Russian Lexicon Entries for pdoArchive
 *
 * @package pdotools
 * @subpackage lexicon
 * @language ru
 */

$_lang['pdoarchive_month_01'] = 'Январь';
$_lang['pdoarchive_month_02'] = 'Февраль';
$_lang['pdoarchive_month_03'] = 'Март';
$_lang['pdoarchive_month_04'] = 'Апрель';
$_lang['pdoarchive_month_05'] = 'Май';
$_lang['pdoarchive_month_06'] = 'Июнь';
$_lang['pdoarchive_month_07'] = 'Июль';
$_lang['pdoarchive_month_08'] = 'Август';
$_lang['pdoarchive_month_09'] = 'Сентябрь';
$_lang['pdoarchive_month_10'] = 'Октябрь';
$_lang['pdoarchive_month_11'] = 'Ноябрь';
$_lang['pdoarchive_month_12'] = 'Декабрь';
