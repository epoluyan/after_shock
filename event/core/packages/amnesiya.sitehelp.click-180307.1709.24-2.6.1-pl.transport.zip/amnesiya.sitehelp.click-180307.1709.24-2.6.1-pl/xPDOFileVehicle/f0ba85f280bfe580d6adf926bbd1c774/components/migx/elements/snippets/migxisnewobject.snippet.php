<?php
if (isset($_REQUEST['object_id']) && $_REQUEST['object_id']=='new'){
    return 1;
}