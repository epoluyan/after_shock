<?php
return include_once(dirname(__FILE__) . "/create.class.php");