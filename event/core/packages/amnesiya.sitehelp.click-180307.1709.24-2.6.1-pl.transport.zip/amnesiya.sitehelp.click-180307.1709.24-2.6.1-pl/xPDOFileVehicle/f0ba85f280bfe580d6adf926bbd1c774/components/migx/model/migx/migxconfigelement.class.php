<?php
class migxConfigElement extends xPDOSimpleObject {}